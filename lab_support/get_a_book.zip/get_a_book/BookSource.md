# Don Quixote by Miguel de Cervantes Saavedra

The provided text at [./book.txt](./book.txt) was downloaded from the [Gutenberg Project](http://www.gutenberg.org/wiki/Main_Page).

This is the link where the book is available: [http://www.gutenberg.org/ebooks/996](http://www.gutenberg.org/ebooks/996)